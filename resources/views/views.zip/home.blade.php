@extends('master.master_new')

@section('header')
    @include('layouts.header')
@endsection

@section('form')
    @include('form.createKorupsi')
@endsection

@section('sikil')
    @include('layouts.sikil')
@endsection


