@extends('master.master')

@section('header')
    @include('layouts.header')
@endsection

@section('form')
    @include('lapor.lapor_korupsi')
@endsection

@section('sikil')
    @include('layouts.sikil')
@endsection

