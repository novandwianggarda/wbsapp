@extends('master.master_new')

@section('header')
    @include('layouts.header-gratifikasi')
@endsection

@section('form')
    @include('form.createGratifikasi')
@endsection

@section('sikil')
    @include('layouts.sikil')
@endsection


