<div id="lapor" class="pricing-section text-center">
    <div class="container">
        <div class="col-md-12 col-sm-12 nopadding">
            <div class="pricing-intro">
                <h1 class="wow fadeInUp" data-wow-delay="0s">LAPORKAN</h1>
                <p class="wow fadeInUp" data-wow-delay="0.2s"> Lorem ipsum dolor sit. Incidunt laborum beatae earum nihil odio consequatur officiis <br class="hidden-xs">
                    tempore consequuntur officia ducimus unde doloribus quod unt repell </p>
            </div>
            <div class="col-sm-4">
                <div class="table-left wow fadeInUp" data-wow-delay="0.4s">
                    <div class="pricing-details">
                        <H1>Korupsi</H1>
                        <ul>
                            <li>Consectetur adipiscing</li>
                            <li>Nunc luctus nulla et tellus</li>
                            <li>Suspendisse quis metus</li>
                            <li>Vestibul varius fermentum erat</li>
                        </ul>
                        <a href="/post_korupsi">
                            <button class="btn btn-primary btn-action btn-fill">Lapor !</button>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="table-right wow fadeInUp" data-wow-delay="0.6s">
                    <div class="pricing-details">
                        <H1>Gratifikasi</H1>
                        <ul>
                            <li>Consectetur adipiscing</li>
                            <li>Nunc luctus nulla et tellus</li>
                            <li>Suspendisse quis metus</li>
                            <li>Vestibul varius fermentum erat</li>
                        </ul>
                        <a href="/post_gratifikasi">
                            <button class="btn btn-primary btn-action btn-fill">Lapor !</button>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="table-right wow fadeInUp" data-wow-delay="0.6s">
                    <div class="pricing-details">
                        <H1>Benturan Kepentingan</H1>
                        <ul>
                            <li>Consectetur adipiscing</li>
                            <li>Nunc luctus nulla et tellus</li>
                            <li>Suspendisse quis metus</li>
                            <li>Vestibul varius fermentum erat</li>
                        </ul>
                        <a href="/post_benturan_kepentingan">
                            <button class="btn btn-primary btn-action btn-fill" href="/laporan_benturan">Lapor !</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>