<div class="footer" id="contact">
    <div class="container">
        <div class="col-md-6 contact">
            <h1>About Trainer</h1>
            <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, <br>
                vel illum dolore eu feugiat nulla facilisis at vero Duis autem vel eum iriure dolor in <br>
                hendrerit in vulputate velit esse eros et accumsan.</p>
            <p>Pellentesque eget dolor gravida, tempus purus ac, ultricies mauris. Etiam est nisl,<br>
                molestie sed egestas bibendum, varius eu diam.</p>
        </div>
        <div class="col-md-3 contact footer-menu">
            <h1>Social</h1>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Twitter</a></li>
                <li><a href="#">Github</a></li>
                <li><a href="#">Pinterest</a></li>
                <li><a href="#">Google Plus</a></li>
            </ul>
        </div>
        <div class="col-md-3 contact">
            <h1>Contact Us</h1>
            <p> Contact our 24/7 customer support if you have any questions. We'll help you out. </p>
            <a href="mailto:support@gmail.com">contact@iland.com</a> </div>
    </div>
</div>