<div id="bg-dewe">
        <div class="container">
            <div class="col-md-12">
                {{--<div class="hero-content text-center">
                    <h1 class="wow fadeInUp" data-wow-delay="0.1s">WBS</h1>
                    <p class="wow fadeInUp" data-wow-delay="0.2s"> Silahkan Laporkan Pegawai Nakal </p>
                    <a href="#lapor" class="btn btn-action wow fadeInUp page-scroll" style="visibility: visible; animation-name: fadeInUp;">Sempriiiiiit</a>
                </div>--}}
                <ul id="scene">
                    <li class="img-responsive" id="a" data-depth="0.40">
                        <img src="{{asset('img/parallax/sign.png')}}" alt="">
                    </li>
                    <li class="img-responsive" id="b" data-depth="0.60">
                        <img src="{{asset('img/parallax/wire.png')}}" alt="">
                    </li>
                    <li class="img-responsive" id="c" data-depth="0.80">
                        <img src="{{asset('img/parallax/caution.png')}}" alt="">
                    </li>
                </ul>
            </div>
        </div>
</div>