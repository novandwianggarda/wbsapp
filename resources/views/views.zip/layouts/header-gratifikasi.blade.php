<section id="home" class="s-home target-section" data-parallax="scroll" data-image-src="{{asset('img/front/hero-bg.jpg')}}" data-natural-width=3000 data-natural-height=2000 data-position-y=center>

    <div class="overlay"></div>
    <div class="shadow-overlay"></div>

    <div class="home-content">

        <div class="row home-content__main">

            <h3>Laporkan Pelaku Gratifikasi</h3>

            <h1>
                Laporke waeeee <br>
                aman amaaaaan, westoooo <br>
                rak tak kandakke wonge wes <br>
                tapi ngko tetep diproses ok, tenang bae !
            </h1>

            <div class="home-content__buttons">
                <a href="#lapor" class="smoothscroll btn btn--stroke">
                    Monggo Lapor
                </a>
            </div>

        </div>

        <div class="home-content__scroll">
            <a href="#lapor" class="scroll-link smoothscroll">
                <span>Scroll Down</span>
            </a>
        </div>

        <div class="home-content__line"></div>

    </div> <!-- end home-content -->


    <ul class="home-social">
        <li>
            <a href="/lapor_korupsi"><i class="fa fa-money" aria-hidden="true"></i><span>Lapor Korupsi</span></a>
        </li>
        <li>
            <a href="/lapor_gratifikasi"><i class="fa fa-prize" aria-hidden="true"></i><span>Lapor Gratifikasi</span></a>
        </li>
        <li>
            <a href="/lapor_benturan_kepentingan"><i class="fa fa-people" aria-hidden="true"></i><span>Lapor Benturan Kepentingan</span></a>
        </li>
    </ul>
    <!-- end home-social -->

</section> <!-- end s-home -->
