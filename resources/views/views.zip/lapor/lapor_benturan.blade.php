@extends('master.master2')

@section('menu')
    @include('layouts.menu')
@endsection
@section('form')
    @include('form.createBenturan')
@endsection

@section('this')
    @include('layouts.sikil2')
@endsection

