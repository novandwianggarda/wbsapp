<div class="footer">

    <div>
        <strong>Copyright</strong> Example Company &copy; 2014-2017
    </div>
</div>